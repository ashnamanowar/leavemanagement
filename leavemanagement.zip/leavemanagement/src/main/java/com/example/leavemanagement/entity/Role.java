package com.example.leavemanagement.entity;

public enum Role {
    EMPLOYEE,
    MANAGER,
    SUPERVISOR
}
