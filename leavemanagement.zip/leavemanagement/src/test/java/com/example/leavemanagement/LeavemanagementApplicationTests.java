package com.example.leavemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeavemanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
